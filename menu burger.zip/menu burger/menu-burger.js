let button = document.querySelector("button");
let rectangle = document.querySelector("#rectangle");
let topLine = document.querySelector("#topline");
let bottomLine = document.querySelector("#bottomline");
let middleLine = document.querySelector("#middleline");
//var region ends here

    button.addEventListener('click', function click (){
        middleLine.classList.toggle("middleLineAnimation");
        bottomLine.classList.toggle("bottomLineAnimation");
        topLine.classList.toggle("topLineAnimation");
        rectangle.classList.toggle("animation");
        button.classList.toggle("buttonAnimation");
    });


    

